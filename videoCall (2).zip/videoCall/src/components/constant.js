export const APP_ID = 1622108664
export const SERVER_SECRET = "4c0b8bc494f09a10d7d1e21b1a22f780"


